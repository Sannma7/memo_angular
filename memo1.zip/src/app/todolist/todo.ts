export class Todo {
  id: number;
  name: string;
  prograss: number;
  total: number;
}
