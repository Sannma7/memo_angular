import { Todo } from './todo';

export const TODOS: Todo[] = [
  { id: 0, name: 'push-up', prograss: 2000, total: 10000 },
  { id: 1, name: 'belly', prograss: 4000, total: 10000 },
  { id: 2, name: 'Lifting', prograss: 6000, total: 10000 },
  { id: 3, name: 'Junping', prograss: 5000, total: 10000 },
  { id: 4, name: 'Running', prograss: 1000, total: 10000 },
]
